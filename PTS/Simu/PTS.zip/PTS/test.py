
import numpy as np
import matplotlib.pyplot as plt


fig, ax = plt.subplots()
ax.plot(np.random.rand(10))



plt.show()